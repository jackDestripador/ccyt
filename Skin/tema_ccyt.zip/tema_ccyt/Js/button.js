/*****************************
UACM| Colegio de ciencia y tecnología
botones Cuerpo colegiados
******************************/

$(document).ready(function () {
     $("#boton1").click(function () {
         $("#panel1").slideToggle("slow");
     });
     $("#boton2").click(function () {
         $("#panel2").slideToggle("slow");
     });
     $("#boton3").click(function () {
         $("#panel3").slideToggle("slow");
     });
     $("#boton4").click(function () {
         $("#panel4").slideToggle("slow");
     });
     $("#boton5").click(function () {
         $("#panel5").slideToggle("slow");
     });

     $("#boton6").click(function () {
         $("#panel6").slideToggle("slow");
     });
 });
