/******MAPA PLANTEL CASA LIBERTAD****/
$('#open-popup_MAPA_CL').magnificPopup({
    items: [
      {
        src: 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d5519.864141499067!2d-99.00053680938325!3d19.356946024513174!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xdea69e44b5e5cef!2sUACM+Casa+Libertad!5e1!3m2!1ses-419!2smx!4v1565730520515!5m2!1ses-419!2smx" width="600" height="450" frameborder="0" style="border:0" allowfullscreen',       
      },
    ],
    gallery: {
      enabled: true
    },
    type: 'iframe' // this is a default type
});
/******MAPA PLANTEL CENTRO HISTORICO****/
$('#open-popup_MAPA_CH').magnificPopup({
    items: [
      {
         src: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4639.7189671423075!2d-99.13774609182329!3d19.42412061763964!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d1ffa6ddb49a5f%3A0x99cef556c779745c!2sUniversidad+Aut%C3%B3noma+de+la+Ciudad+de+M%C3%A9xico+Plantel+Centro+Hist%C3%B3rico!5e1!3m2!1ses-419!2sus!4v1565725610232!5m2!1ses-419!2sus" width="600" height="450" frameborder="0" style="border:0" allowfullscreen',       
      },
    ],
    gallery: {
      enabled: true
    },
    type: 'iframe' // this is a default type
});
/******MAPA PLANTEL CUAUTEPEC****/
$('#open-popup_MAPA_CU').magnificPopup({
    items: [
      {
        src: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d998.042680738665!2d-99.14273730857789!3d19.555792748673486!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d1f70bc671f871%3A0x34bc8e1062c25c2e!2sUACM+Plantel+Cuautepec!5e1!3m2!1ses-419!2smx!4v1562791511681!5m2!1ses-419!2smx',     
      },
    ],
    gallery: {
      enabled: true
    },
    type: 'iframe' // this is a default type
});
/******MAPA PLANTEL DEL VALLE****/
$('#open-popup_MAPA_DV').magnificPopup({
    items: [
      {
        src: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2193.7089830620334!2d-99.17214631828689!3d19.374424316330224!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d1ffa0ffffffff%3A0xa49ba9e33484b07f!2sUACM+Del+Valle!5e1!3m2!1ses-419!2sus!4v1565730882218!5m2!1ses-419!2sus" width="600" height="450" frameborder="0" style="border:0" allowfullscreen',
      },      
    ],
    gallery: {
      enabled: true
    },
    type: 'iframe' // this is a default type
});
/******MAPA PLANTEL SLT****/
$('#open-popup_MAPA_SLT').magnificPopup({
    items: [
      {
        src: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d11042.732031666997!2d-99.061445479639!3d19.312522255314402!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85ce025ef919d837%3A0x8976a765f69064e3!2sUACM+San+Lorenzo+Tezonco!5e1!3m2!1ses-419!2smx!4v1565730956220!5m2!1ses-419!2smx" width="600" height="450" frameborder="0" style="border:0" allowfullscreen',
      },
    ],
    gallery: {
      enabled: true
    },
    type: 'iframe' // this is a default type
});

























